console.log('%c'+"STOP..! , THIS CONSOLE IS ONLY FOR ADMIN USE, YOU MAY GET BLOCKED FROM OUR CHATROOM IF YOU USE THIS CONSOLE.", 'font-weight: bold; font-size: 14px;color: red; text-shadow: 0px 0px 5px black; border: 2px Solid black; padding:6px; border-radius:10px; display:block;');
var foradmin='You are an admin & thats why you cannot ignore a user because your duty is to block users who violate, and if you ignore someone so you will not be able to see his messages.';        
        
// Initialize Firebase
  // Initialize Firebase
// Initialize Firebase
var config = {
  apiKey: "AIzaSyAmORU-RRHsioSGjwaKFkJbo5TE2E0SIN8",
  authDomain: "one-to-one-29381.firebaseapp.com",
  databaseURL: "https://one-to-one-29381.firebaseio.com",
  projectId: "one-to-one-29381",
  storageBucket: "",
  messagingSenderId: "1053318516854"
};
firebase.initializeApp(config);


